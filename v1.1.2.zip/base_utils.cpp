/*
==============================
base utils for C++17-C++20
version this utils - 1.1.2
using: using namespace std;
==============================
*/
#include<iostream>
#include <string>
#include <iomanip>
#include <bitset>
#include <iterator>
#include <chrono>
#include <ctime>
#include<vector>
#include<cmath>
#include<algorithm>
#include <stdexcept>
using namespace std;
void p(const string& text)
{
	cout << text;
}
void tws(const string& text, int a, int b)
{
	cout << text << a + b;
}
void ths(const string& text, int a, int b, int c)
{
	cout << text << a + b + c;
}
void fos(const string& text, int a, int b, int c, int d)
{
	cout << text << a + b + c + d;
}
void mtw(const string& text, int a, int b)
{
	cout << text << a * b;
}
void mth(const string& text, int a, int b, int c)
{
	cout << text << a * b * c;
}
void mfo(const string& text, int a, int b, int c, int d)
{
	cout << text << a * b * c * d;
}
void vtw(const string& text, int a, int b)
{
	cout << text << a - b;
}
void vth(const string& text, int a, int b, int c)
{
	cout << text << a - b - c;
}
void vfo(const string& text, int a, int b, int c, int d)
{
	cout << text << a - b - c - d;
}
void dtw(const string& text, int a, int b)
{
	cout << text << a / b;
}
void dth(const string& text, int a, int b, int c)
{
	cout << text << a / b / c;
}
void dfo(const string& text, int a, int b, int c, int d)
{
	cout << text << a / b / c / d;
}
void onc(const string& text, int a)
{
	cout << text; cin >> a;
}
void twc(const string& text, int a, int b)
{
	cout << text; cin >> a; cout << text; cin >> b;
}
void thc(const string& text, int a, int b, int c)
{
	cout << text; cin >> a; cout << text; cin >> b; cout << text; cin >> c;
}
void foc(const string& text, int a, int b, int c, int d)
{
	cout << text; cin >> a; cout << text; cin >> b; cout << text; cin >> c; cout << text; cin >> d;
}
void tof(const string& ftext, bool a, const string& stext)
{
	if (a == true) cout << ftext;
	else if (a == false) cout << stext;
}
void twm(const string& ftext, int a, int b, const string& stext, const string& ttext)
{
	if (a > b) cout << ftext;
	else if (a < b) cout << stext;
	else if (a == b) cout << ttext;
}
void prepeat(int n, const std::string& text) {
    for (int i = 0; i < n; ++i)
        cout << text;
}
void phex(const string& text, int n) {
	cout << text << hex << n << dec;
}
void pbin(const string& text, int n) {
    cout << text;
    if (n == 0) {
        cout << '0';
        return;
    }
    bool started = false;
    for (int i = sizeof(n)*8 - 1; i >= 0; --i) {
        if ((n >> i) & 1) started = true;
        if (started) cout << ((n >> i) & 1);
    }
}
void poct(const string& text, int n) {
    cout << text << oct << n << dec;
}
void it(const string& ftext, const string& stext, string x)
{
	if (x == stext) cout << ftext;
}
void ic(const string& ftext, char fchar, char x)
{
	if (x == fchar) cout << ftext;
}
template<typename Container>
void pco(const Container& c, const string& delimiter = ", ") {
	auto it = begin(c);
	auto end = end(c);
	if (it == end) return;
	std::cout << *it;
	for (++it; it != end; ++it) {
		cout << delimiter << *it << "\n";
	}
}
void pap(const string& text, int start, int difference, int count) {
	if (count <= 0) {
		return;
	}
	cout << text << start
		<< ", d=" << difference << "): ";
	for (int i = 0; i < count; ++i) {
		cout << start + i * difference;
		if (i < count - 1) cout << ", ";
	}
	cout << std::endl;
}
void pgp(const string& text, double start, double ratio, int count) {
	if (count <= 0) {
		return;
	}
	std::cout << text << start
		<< ", q=" << ratio << "): ";
	double term = start;
	for (int i = 0; i < count; ++i) {
		std::cout << term;
		if (i < count - 1) cout << ", ";
		term *= ratio;
	}
	cout << endl;
}
void dts(const string& type, int speed, int time, int distance)
{
	if (type == "speed") cout << distance / time;
	else if (type == "time") cout << distance / speed;
	else if (type == "distance") cout << speed * time;
}
void pf(int n) {
	if (n < 0) {
		return;
	}
	unsigned long long fact = 1;
	for (int i = 1; i <= n; ++i) {
		fact *= i;
	}
	cout << fact << endl;
}
void pc(char symbol = '-', int width = 50) {
	for (int i = 0; i < width; ++i)
		cout << symbol;
	cout << '\n';
}
void average(const int arr[], int size, double& result) {
	if (size <= 0) {
		result = 0.0;
		return;
	}
	double sum = 0.0;
	for (int i = 0; i < size; ++i) {
		sum += arr[i];
	}
	result = sum / size;
}
void am(const vector<double>& data, double& result) {
	if (data.empty()) {
		result = 0.0;
		return;
	}
	double sum = 0.0;
	for (double x : data) sum += x;
	result = sum / data.size();
}
void sumv(const vector<double>& data, double& result) {
	result = 0.0;
	for (double x : data) result += x;
}
void prv(const vector<double>& data, double& result) {
	if (data.empty()) {
		result = 0.0;
		return;
	}
	result = 1.0;
	for (double x : data) result *= x;
}
void miv(const vector<double>& data, double& result) {
	if (data.empty()) throw invalid_argument("Empty vector");
	result = *min_element(data.begin(), data.end());
}
void mav(const vector<double>& data, double& result) {
	if (data.empty()) throw invalid_argument("Empty vector");
	result = *max_element(data.begin(), data.end());
}
void median(vector<double> data, double& result) {
	if (data.empty()) throw invalid_argument("Empty vector");
	sort(data.begin(), data.end());
	size_t n = data.size();
	if (n % 2 == 0)
		result = (data[n / 2 - 1] + data[n / 2]) / 2.0;
	else
		result = data[n / 2];
}
void pi(int base, int exp, long long& result) {  //pi и дор это не смешно!!!
	if (exp < 0) {
		result = 0;
		return;
	}
	result = 1;
	for (int i = 0; i < exp; ++i) result *= base;
}
void gcd(int a, int b, int& result) {
	a = std::abs(a);
	b = std::abs(b);
	while (b != 0) {
		int temp = b;
		b = a % b;
		a = temp;
	}
	result = a;
}
void lcm(int a, int b, int& result) {
	int g = 0;
	gcd(a, b, g);
	if (g == 0) result = 0;
	else result = std::abs(a / g) * b;
}
void ip(int n, bool& result) {
	if (n <= 1) {
		result = false;
		return;
	}
	if (n <= 3) {
		result = true;
		return;
	}
	if (n % 2 == 0 || n % 3 == 0) {
		result = false;
		return;
	}
	for (int i = 5; i * i <= n; i += 6) {
		if (n % i == 0 || n % (i + 2) == 0) {
			result = false;
			return;
		}
	}
	result = true;
}
void ra(double width, double height, double& area) {
	area = width * height;
}
void hy(double a, double b, double& c) {
	c = sqrt(a * a + b * b);
}
void ed(double x1, double y1, double x2, double y2, double& dist) {
	double dx = x2 - x1;
	double dy = y2 - y1;
	dist = sqrt(dx * dx + dy * dy);
}
void qr(double a, double b, double c, int& num_roots, double& x1, double& x2) {
	if (abs(a) < 1e-12) { 
		if (abs(b) < 1e-12) {
			num_roots = 0;
			x1 = x2 = 0.0;
		}
		else {
			num_roots = 1;
			x1 = x2 = -c / b;
		}
		return;
	}
	double disc = b * b - 4.0 * a * c;
	if (disc < -1e-12) {
		num_roots = 0;
		x1 = x2 = 0.0;
	}
	else if (std::abs(disc) < 1e-12) {
		num_roots = 1;
		x1 = x2 = -b / (2.0 * a);
	}
	else {
		num_roots = 2;
		double sqrt_disc = std::sqrt(disc);
		x1 = (-b + sqrt_disc) / (2.0 * a);
		x2 = (-b - sqrt_disc) / (2.0 * a);
	}
}
void ls(double x, int terms, double& result) {
	if (x <= -1.0) {
		result = -1e100;
		return;
	}
	result = 0.0;
	for (int n = 1; n <= terms; ++n) {
		double term = (n % 2 == 1 ? 1.0 : -1.0) * pow(x, n) / n;
		result += term;
	}
}
void dp(const vector<double>& u, const vector<double>& v, double& result) {
	if (u.size() != v.size() || u.empty()) {
		result = 0.0;
		return;
	}
	result = 0.0;
	for (size_t i = 0; i < u.size(); ++i)
		result += u[i] * v[i];
}
